using System.Configuration;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using System.Net.Http.Headers;
using System.Text;
using Newtonsoft.Json;
using CxOneDailerClientPOC.AdminAPIs;

namespace CxOneDailerClientPOC
{
    public partial class ClientForm : Form
    {
        public string AuthTokenBaseUrl { get; set; }
        public string ClientId { get; set; }
        public string ClientSecret { get; set; }
        public string AccessKeyId { get; set; }
        public string SecretAccessKey { get; set; }
        public string GrantType { get; set; }

        public string AccessToken { get; set; }


        public ClientForm()
        {
            InitializeComponent();

            AuthTokenBaseUrl = ConfigurationManager.AppSettings["AuthTokenBaseUrl"];
            ClientId = ConfigurationManager.AppSettings["ClientId"];
            ClientSecret = ConfigurationManager.AppSettings["ClientSecret"];

            GrantType = "password";
            AccessKeyId = ConfigurationManager.AppSettings["AccessKeyId"];
            SecretAccessKey = ConfigurationManager.AppSettings["SecretAccessKey"];
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var result = string.Empty;
            var Url = new Uri($"{AuthTokenBaseUrl}/auth/token");
            var authValue = new AuthenticationHeaderValue("Basic",
                            Convert.ToBase64String(Encoding.UTF8.GetBytes($"{ClientId}:{ClientSecret}")));

            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization = authValue;

                var content = new FormUrlEncodedContent(new[]
                {
                    new KeyValuePair<string, string>("grant_type", GrantType),
                    new KeyValuePair<string, string>("username", AccessKeyId),
                    new KeyValuePair<string, string>("password", SecretAccessKey)
                });

                var response = client.PostAsync(Url, content).Result;

                if (response.IsSuccessStatusCode)
                {
                    result = response.Content.ReadAsStringAsync().Result;
                    var tokenResponse = JsonConvert.DeserializeObject<TokenResponse>(result);
                    AccessToken = tokenResponse?.access_token;
                    textbox_Token.Text = tokenResponse?.access_token;
                }
                else
                {
                    textbox_Token.Text = "Error retrieving the token.";
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var dialer = new DailerInterface(AccessToken);
            var result = dialer.SendMembersToCampaign();
            tbCampaign.Text = result;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            var dialer = new DailerInterface(AccessToken);
            var result = dialer.RemoveMembersFromCampaign();
            tbRemoveMembs.Text = result;
        }

        private void btnSchduleCallbcks_Click(object sender, EventArgs e)
        {
            var dialer = new DailerInterface(AccessToken);
            var result = dialer.ScheduleCallbacks();
            tbRemoveMembs.Text = result;
        }

        private void tbRetrivemembers_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            var dialer = new DailerInterface(AccessToken);
            var result = dialer.RetrieveMembersIncludedInCallingList();
            tbRetrivemembers.Text = result;
        }
    }
}
