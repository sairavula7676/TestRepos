﻿using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CXOneDailerPOC.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        public string ClientId { get; set; }
        public string ClientSecret { get; set; }

        // GET: api/<AuthController>
        [HttpGet]
        public string GetToken()
        {
            
        }

        

        // POST api/<AuthController>
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

    }
}
