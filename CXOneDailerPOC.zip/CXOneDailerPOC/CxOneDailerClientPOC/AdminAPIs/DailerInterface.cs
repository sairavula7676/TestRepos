﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace CxOneDailerClientPOC.AdminAPIs
{
    public class DailerInterface
    {
        public string AuthTokenBaseUrl { get; set; }
        public string AdminAPIBaseUrl { get; set; }
        public string ClientId { get; set; }
        public string ClientSecret { get; set; }
        public string AccessKeyId { get; set; }
        public string SecretAccessKey { get; set; }
        public string GrantType { get; set; }

        public string AccessToken { get; set; }
        public int SkillId { get; set; }
        public int CallingListId { get; set; }
        public DailerInterface(string AccessToken)
        {
            AuthTokenBaseUrl = ConfigurationManager.AppSettings["AuthTokenBaseUrl"];
            AdminAPIBaseUrl = ConfigurationManager.AppSettings["AdminAPIBaseUrl"];
            ClientId = ConfigurationManager.AppSettings["ClientId"];
            ClientSecret = ConfigurationManager.AppSettings["ClientSecret"];

            GrantType = "password";
            AccessKeyId = ConfigurationManager.AppSettings["AccessKeyId"];
            SecretAccessKey = ConfigurationManager.AppSettings["SecretAccessKey"];
            this.AccessToken = AccessToken;

            SkillId = 20954693;
            CallingListId = 234865;
        }
        public string SendMembersToCampaign()
        {
            return AddMembersToCallingList();
        }

        public string RemoveMembersFromCampaign()
        {
            return RemoveMembersFromCallingList();
        }

        //202095
        public string RetrieveMembersIncludedInCallingList()
        {
            var result = string.Empty;
            var Url = new Uri($"{AdminAPIBaseUrl}/lists/call-lists/202095?finalized=true&fields=externalId&top=10");
            var authValue = new AuthenticationHeaderValue("Bearer", AccessToken);

            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.Authorization = authValue;

                //var fileName = "CHC_UCare_MD_PC_NoAgent.csv";
                //var filePath = "C:\\Users\\sravul11\\Downloads\\List\\CHC_UCare_MD_PC_NoAgent.csv";
                //var base64String = Convert.ToBase64String(File.ReadAllBytes(filePath));

                //var content = new FormUrlEncodedContent(new[]
                //{
                //    new KeyValuePair<string, string>("listFile", base64String),
                //    new KeyValuePair<string, string>("fileName", fileName),
                //    new KeyValuePair<string, string>("skillId", SkillId.ToString()),
                //    new KeyValuePair<string, string>("defaultTimeZone", "UTC"),
                //    new KeyValuePair<string, string>("forceOverwrite", "true"),
                //    new KeyValuePair<string, string>("expirationDate", "2025-04-12T19:56:58.000Z"),
                //    new KeyValuePair<string, string>("startSkill", "true"),
                //    new KeyValuePair<string, string>("sendEmail", "true"),
                //});


                var response = client.GetAsync(Url).Result;

                if (response.IsSuccessStatusCode)
                {
                    result = response.Content.ReadAsStringAsync().Result;
                    return response.StatusCode + Environment.NewLine + response.ReasonPhrase + Environment.NewLine + result;
                }

                return "Request failed.";
            }
        }

        private string AddMembersToCallingList()
        {
            var result = string.Empty;
            var Url = new Uri($"{AdminAPIBaseUrl}/lists/call-lists/{CallingListId}/upload");
            var authValue = new AuthenticationHeaderValue("Bearer", AccessToken);

            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.Authorization = authValue;

                //var fileName = "CHC_UCare_MD_PC_NoAgent.csv";
                //var filePath = "C:\\Users\\sravul11\\Downloads\\List\\CHC_UCare_MD_PC_NoAgent.csv";

                var fileName = "TestList.csv";
                var filePath = "C:\\Users\\sravul11\\Downloads\\List\\TestList.csv";

                var base64String = Convert.ToBase64String(File.ReadAllBytes(filePath));

                var content = new FormUrlEncodedContent(new[]
                {
                    new KeyValuePair<string, string>("listFile", base64String),
                    new KeyValuePair<string, string>("fileName", fileName),
                    new KeyValuePair<string, string>("skillId", SkillId.ToString()),
                    new KeyValuePair<string, string>("defaultTimeZone", "UTC"),
                    new KeyValuePair<string, string>("forceOverwrite", "true"),
                    new KeyValuePair<string, string>("expirationDate", "2025-04-12T19:56:58.000Z"),
                    new KeyValuePair<string, string>("startSkill", "true"),
                    new KeyValuePair<string, string>("sendEmail", "true"),
                });


                var response = client.PostAsync(Url, content).Result;

                if (response.IsSuccessStatusCode)
                {
                    result = response.Content.ReadAsStringAsync().Result;
                    return response.StatusCode + Environment.NewLine + response.ReasonPhrase;
                }

                return "Request failed.";
            }
        }

        private string RemoveMembersFromCallingList()
        {
            //CallingList Name 
            var sourceName = "April 2024 Surprise Health Center 1";
            var externalId = "6624308";

            var result = string.Empty;
            var Url = new Uri($"{AdminAPIBaseUrl}/lists/call-lists/{sourceName}/removeProspects");
            var authValue = new AuthenticationHeaderValue("Bearer", AccessToken);

            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Clear();
                client.DefaultRequestHeaders.Accept.Clear();

                client.DefaultRequestHeaders.Authorization = authValue;
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var requestBody = new ProspectRequest
                {
                    prospectsToRemove = new List<ProspectsToRemove>
                    {
                        new ProspectsToRemove
                        {
                            externalId = externalId
                        }
                    }
                };
                var serializeObject = JsonConvert.SerializeObject(requestBody);
                var content = new StringContent(serializeObject);

                var request = new HttpRequestMessage
                {
                    Method = HttpMethod.Delete,
                    RequestUri = Url,
                    Content = content
                };

                var response = client.SendAsync(request).Result;

                if (response.IsSuccessStatusCode)
                {
                    result = response.Content.ReadAsStringAsync().Result;
                    return response.StatusCode + Environment.NewLine +
                        response.ReasonPhrase + Environment.NewLine + result;
                }
                else
                {
                    return response.StatusCode + Environment.NewLine + response.ReasonPhrase;
                }
            }
        }

        public string ScheduleCallbacks()
        {
            var result = string.Empty;
            var Url = new Uri($"{AdminAPIBaseUrl}/scheduled-callbacks");
            var authValue = new AuthenticationHeaderValue("Bearer", AccessToken);

            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization = authValue;

                var content = new FormUrlEncodedContent(new[]
                {
                    new KeyValuePair<string, string>("phoneNumber", "3347813565"),
                    new KeyValuePair<string, string>("skillId", "0"),
                    new KeyValuePair<string, string>("scheduleDate", "2024-04-12 10:20:00.000"),
                    new KeyValuePair<string, string>("firstName", "Saikumar"),
                    new KeyValuePair<string, string>("lastName", "Ravula"),
                    new KeyValuePair<string, string>("targetAgentId", ""),
                    new KeyValuePair<string, string>("notes", "Testing")
                });

                var response = client.PostAsync(Url, content).Result;

                if (response.IsSuccessStatusCode)
                {
                    result = response.Content.ReadAsStringAsync().Result;
                    return response.StatusCode + Environment.NewLine +
                        response.ReasonPhrase + Environment.NewLine + result;
                }
                else
                {
                    return response.StatusCode + Environment.NewLine + response.ReasonPhrase;
                }
            }
        }
    }

    public class CallingListRequest
    {
        public string listFile { get; set; }
        public string fileName { get; set; }
        public int skillId { get; set; }
        public string defaultTimeZone { get; set; }
        public bool forceOverwrite { get; set; }
        public string expirationDate { get; set; }
        public bool startSkill { get; set; }
    }

    public class ProspectsToRemove
    {
        public string externalId { get; set; }
    }

    public class ProspectRequest
    {
        public List<ProspectsToRemove> prospectsToRemove { get; set; }
    }
}
